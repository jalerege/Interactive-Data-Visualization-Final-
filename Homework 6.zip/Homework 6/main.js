d3.json("ct-towns-2022-simple-datactgov.geojson").then((geojson)=> {
    d3.dsv(",","CT_median-home-value-town-2019.csv", d => {
        if(d.Variable == "Median Home Value" && d["Measure Type"] == "Number"){
            return {
                town: d.Town,
                value: +d.Value,
            };
        }
    }).then((data)=> {
        console.log("loaded csv",data);
        console.log("loaded json", geojson);

        let datajoin;
        datajoin = {};
        data.forEach(d => {
            datajoin[d.town] = d.value;
        });

        geojson.features.forEach(feature => {
            const townname = feature.properties.name;
            feature.properties.value = datajoin[townname] || null;
        })

        let maxValue = d3.max(data, d => d.value);
        let minValue = d3.min(data, d => d.value);
        let midValue = minValue +(maxValue - minValue)/2;

        var colorScale = d3.scaleDiverging([minValue, midValue, maxValue], d3.interpolatePiYG);

        let map = L.map('map').setView([41.38016733657364, -72.10705729845692], 8);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18,
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);

        function style(feature) {
            console.log(feature.properties.value)
            return {
                fillColor:colorScale(feature.properties.value),
                weight: 1,
                opacity: 0.8,
                color: "white",
                fillOpacity: 0.8,
            };
        }

        var info = L.control(); //adding the info box in the corner
        info.onAdd = function (map) {
            this._div = L.DomUtil.create('div', 'info');
            this.update();
            return this._div;
        };
        info.update = function (props) {
            this._div.innerHTML = '<h4>CT Median Home Value</h4>' + (props ?
                '<b>' + props.name + '</b><br />' +
                (props.value ? '$' + props.value.toLocaleString() : 'No data')
                : 'Hover over a town');
        };
        info.addTo(map);

        // adding the interactivity
        function highlightFeature(e) {
            var layer = e.target;
            layer.setStyle({
                weight: 5,
                color: '#7496fa',
                fillOpacity: 0.7
            });
            layer.bringToFront();
            info.update(layer.feature.properties);
        }

        function resetHighlight(e) {
            geojsonLayer.resetStyle(e.target);
            info.update();
        }

        function zoomToFeature(e) {
            map.fitBounds(e.target.getBounds());
        }

        function onEachFeature(feature, layer) {
            layer.on({
                mouseover: highlightFeature,
                mouseout: resetHighlight,
                click: zoomToFeature
            });
        }

        let geojsonLayer = L.geoJSON(geojson, {
            style: style,
            onEachFeature: onEachFeature
        }).addTo(map);

        // adding the legend
        var legend = L.control({position: 'bottomright'});
        legend.onAdd = function (map) {
            var div = L.DomUtil.create('div', 'info legend');
            var grades = [minValue,
                minValue + (maxValue - minValue) * 0.2,
                minValue + (maxValue - minValue) * 0.4,
                minValue + (maxValue - minValue) * 0.6,
                minValue + (maxValue - minValue) * 0.8, maxValue];

            for (var i = 0; i < grades.length; i++) {
                div.innerHTML +=
                    '<i style="background:' + colorScale(grades[i]) + '"></i> ' +
                    '$' + Math.round(grades[i]).toLocaleString() +
                    (grades[i + 1] ? '&ndash;$' + Math.round(grades[i + 1]).toLocaleString() + '<br>' : '+');
            }

            return div;
        };
        legend.addTo(map);
    })
});